Notepad++
---------


Definiowanie nowego stylu j�zyka:
---------------------------------

Sk�adnia > Define your language... > Import > userDefineLang_mads.xml



Podkolorowanie komunikat�w konsoli:
-----------------------------------

Pluginy > NppExec > Console Output Filters... > HighLight

%ABSFILE% (%LINE%) WARNING:*
%ABSFILE% (%LINE%) ERROR:*



Dodatkowa konsola z eksploratorem dysku:
----------------------------------------

Pluginy -> Plugin Manager -> Show Plugin Manager -> Available -> Explorer (checked) -> Install

W��cz plugin -> Pluginy -> Explorer ->  Explorer ... (checked)



Dodatkowa konsola z informacj� o strukturze pliku:
--------------------------------------------------

Pluginy -> Plugin Manager -> Show Plugin Manager -> Available -> Source Cookifier (checked) -> Install

Pluginy -> SourceCookifier -> Language settings -> SourceCookifier.mads.xml

W��cz plugin -> Pluginy -> SourceCookifier -> Toogle SourceCookifier (checked)
