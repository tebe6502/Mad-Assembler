Iceblox Plus
Program and graphics by Karl H�rnell
(c) Eweguo 2018

Last modified Jan 16 2018 � added a cheat code and an end screen.

This project was set up on a Mac, to be used with the Dustlayer development tools.
http://dustlayer.com/c64-coding-tutorials/2013/2/10/dust-c64-command-line-tool
