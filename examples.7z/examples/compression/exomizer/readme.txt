https://codebase64.org/doku.php?id=base:exomizer_level_compress_decompression_for_beginners
